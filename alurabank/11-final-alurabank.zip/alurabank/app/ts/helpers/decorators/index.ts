export * from './logarTempoDeExecucao';
export * from './domInject';
export * from './throttle';