export interface Imprimivel {

    paraTexto(): void; 
}