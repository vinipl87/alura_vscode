const commentRoutes = require("./comment"),
  photoRoutes = require("./photo"),
  userRoutes = require("./user"),
  feedRoutes = require("./feed");

module.exports = { commentRoutes, photoRoutes, userRoutes, feedRoutes };
