const commentAPI = require("./comment"),
  photoAPI = require("./photo"),
  userAPI = require("./user"),
  feedAPI = require("./feed");

module.exports = { commentAPI, photoAPI, userAPI, feedAPI };
